echo "backup berjalan..."
tar -czvf backup-$(date +%F).tar.gz ~/devops-latihan
